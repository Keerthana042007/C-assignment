#include <iostream>
using namespace std;

class Shopping {
public:
    virtual void bill() = 0;
};

class Product : public Shopping {
    int price;
public:
    void get() {
        cout << "Enter Price: ";
        cin >> price;
    }
    void bill() {
        cout << "Bill Amount: Rs." << price << endl;
    }
};

int main() {
    Product p;
    p.get();
    p.bill();
}
