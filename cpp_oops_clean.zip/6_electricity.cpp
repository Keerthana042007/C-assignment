#include <iostream>
using namespace std;

class Electricity {
protected:
    int units;
public:
    void get() {
        cout << "Enter Units: ";
        cin >> units;
    }
};

class Bill : public Electricity {
public:
    void calculate() {
        float amount;
        if (units <= 100)
            amount = units * 1.5;
        else
            amount = units * 2.5;

        cout << "Total Bill: Rs." << amount << endl;
    }
};

int main() {
    Bill b;
    b.get();
    b.calculate();
}
