#include <iostream>
using namespace std;

class Waste {
protected:
    int q;
public:
    void get() {
        cout << "Enter Waste Quantity: ";
        cin >> q;
    }
    virtual void process() {
        cout << "Processing Waste..." << endl;
    }
};

class Recycle : public Waste {
public:
    void process() {
        cout << "Recycling " << q << " kg waste ♻️" << endl;
    }
};

int main() {
    Waste* w = new Recycle();
    w->get();
    w->process();
    delete w;
}
