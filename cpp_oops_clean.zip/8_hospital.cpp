#include <iostream>
using namespace std;

class Person {
protected:
    string name;
public:
    void getName() {
        cout << "Enter Name: ";
        cin >> name;
    }
};

class Patient : public Person {
protected:
    int age;
public:
    void getAge() {
        cout << "Enter Age: ";
        cin >> age;
    }
};

class Treatment : public Patient {
public:
    void display() {
        cout << "\nPatient Details\n";
        cout << "Name : " << name << endl;
        cout << "Age  : " << age << endl;
    }
};

int main() {
    Treatment t;
    t.getName();
    t.getAge();
    t.display();
}
