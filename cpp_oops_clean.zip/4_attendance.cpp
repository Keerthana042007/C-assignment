#include <iostream>
using namespace std;

class Student {
protected:
    int total, present;
public:
    void get() {
        cout << "Enter Total Days: ";
        cin >> total;
        cout << "Enter Present Days: ";
        cin >> present;
    }
};

class Attendance : public Student {
public:
    void show() {
        float percent = (float)present / total * 100;
        cout << "Attendance Percentage: " << percent << "%" << endl;
    }
};

int main() {
    Attendance a;
    a.get();
    a.show();
}
