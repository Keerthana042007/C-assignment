#include <iostream>
using namespace std;

class Food {
protected:
    string item;
public:
    void get() {
        cout << "Enter Food Item: ";
        cin >> item;
    }
};

class Veg : public Food {
public:
    void show() {
        cout << "Veg Item: " << item << endl;
    }
};

class NonVeg : public Food {
public:
    void show() {
        cout << "Non-Veg Item: " << item << endl;
    }
};

int main() {
    Veg v;
    NonVeg n;

    v.get();
    v.show();

    n.get();
    n.show();
}
