#include <iostream>
using namespace std;

class Bank {
public:
    virtual void interest() {
        cout << "General Interest" << endl;
    }
};

class SBI : public Bank {
public:
    void interest() {
        cout << "SBI Interest: 6%" << endl;
    }
};

class HDFC : public Bank {
public:
    void interest() {
        cout << "HDFC Interest: 7%" << endl;
    }
};

int main() {
    Bank* b;
    SBI s;
    HDFC h;

    b = &s;
    b->interest();

    b = &h;
    b->interest();
}
