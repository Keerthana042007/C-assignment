#include <iostream>
using namespace std;

class Device {
protected:
    string location;
public:
    void getDevice() {
        cout << "Enter Device Location: ";
        cin >> location;
    }
};

class Light : public Device {
protected:
    int brightness;
public:
    void getLight() {
        cout << "Enter Brightness: ";
        cin >> brightness;
    }
};

class Fan : public Device {
protected:
    int speed;
public:
    void getFan() {
        cout << "Enter Speed: ";
        cin >> speed;
    }
};

class SmartController : public Light, public Fan {
public:
    void display() {
        cout << "\n--- Smart Home Status ---\n";
        cout << "Location      : " << Light::location << endl;
        cout << "Brightness    : " << brightness << endl;
        cout << "Fan Speed     : " << speed << endl;
    }
};

int main() {
    SmartController s;
    s.Light::getDevice();
    s.getLight();
    s.getFan();
    s.display();
}
