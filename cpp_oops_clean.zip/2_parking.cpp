#include <iostream>
using namespace std;

class Parking {
public:
    virtual void fee() {
        cout << "General Parking Fee" << endl;
    }
};

class Car : public Parking {
public:
    void fee() {
        cout << "Car Parking Fee: Rs.100" << endl;
    }
};

int main() {
    Parking* p = new Car();
    p->fee();
    delete p;
}
