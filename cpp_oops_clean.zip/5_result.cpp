#include <iostream>
using namespace std;

class Student {
protected:
    int marks;
public:
    void get() {
        cout << "Enter Marks: ";
        cin >> marks;
    }
};

class Result : public Student {
public:
    void show() {
        if (marks >= 50)
            cout << "Result: PASS" << endl;
        else
            cout << "Result: FAIL" << endl;
    }
};

int main() {
    Result r;
    r.get();
    r.show();
}
